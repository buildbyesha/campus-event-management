Campus Event Management & Registration Portal — source bundle

Open index.html to start. Keep all HTML files, style.css, and banner.svg in the same folder.
This is a static front-end demo; it does not have a backend/database.

Known gap: the pages link to contact.html, but no contact.html was supplied in the source set.
